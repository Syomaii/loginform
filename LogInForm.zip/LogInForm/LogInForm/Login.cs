﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogInForm
{
    public partial class Login : Form
    {
        public SqlConnection sqlCon;
        public Login()
        {
            InitializeComponent();
            sqlCon = new SqlConnection("Data Source=CSLAB423\\SQLEXPRESS;Initial Catalog=syomai;Integrated Security=True");
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtBoxUser.Text;
            string password = txtBoxPass.Text;
            string query = "Select count(*) from S_REGISTERED_ACC where S_Username = @Username and S_Password = @Password";
            sqlCon.Open();

            SqlCommand com = new SqlCommand(query, sqlCon);
            com.Parameters.AddWithValue("@Username", username);
            com.Parameters.AddWithValue("@Password", password);

            try
            {
                int count = (int)com.ExecuteScalar();

                if (count > 0)
                {
                    mainForm main = new mainForm();
                    main.ShowDialog();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
        }
    }
}
