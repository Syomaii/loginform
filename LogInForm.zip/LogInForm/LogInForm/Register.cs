﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogInForm
{
    public partial class Register : Form
    {
        public SqlConnection connection;
        public Register()
        {
            InitializeComponent();
            connection = new SqlConnection("Data Source=CSLAB423\\SQLEXPRESS;Initial Catalog=syomai;Integrated Security=True");
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtBoxUser.Text;
            string password = txtBoxPass.Text;
            string SqlRegQuery = "Insert into S_REGISTERED_ACC (Username, Password) values (@Username, @Password)";

            connection.Open();
            SqlCommand sqlCom = new SqlCommand(SqlRegQuery, connection);
            sqlCom.Parameters.AddWithValue("@Username", username);
            sqlCom.Parameters.AddWithValue("@Password", password);
            


        }

        
    }
}
